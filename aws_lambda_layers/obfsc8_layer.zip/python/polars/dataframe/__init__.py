from polars.dataframe.frame import DataFrame

__all__ = [
    "DataFrame",
]
