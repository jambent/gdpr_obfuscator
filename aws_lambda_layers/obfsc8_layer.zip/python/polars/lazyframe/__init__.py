from polars.lazyframe.frame import LazyFrame
from polars.lazyframe.in_process import InProcessQuery

__all__ = ["LazyFrame", "InProcessQuery"]
