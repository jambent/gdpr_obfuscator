from polars.io.parquet.functions import read_parquet, read_parquet_schema, scan_parquet

__all__ = [
    "read_parquet",
    "read_parquet_schema",
    "scan_parquet",
]
