from polars.io.pyarrow_dataset.functions import scan_pyarrow_dataset

__all__ = [
    "scan_pyarrow_dataset",
]
